# SPDX-FileCopyrightText: 2025-present Guille-ux <guilleleiratemes@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.0.7"
